class UserLocation {
  final double latitude;
  final double longitude;

  UserLocation({this.latitude = 0.0, this.longitude = 0});
}
