class Posicion {
  double latitude;
  double longitude;

    Posicion({
    this.longitude=0.0,
    this.latitude=0.0
  });

}